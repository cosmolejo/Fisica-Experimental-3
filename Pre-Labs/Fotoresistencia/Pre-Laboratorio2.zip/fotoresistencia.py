import pyfirmata
import os
from time import sleep
import numpy as np
import pylab as plt
from drawnow import drawnow #ojo en general el archivo usa de plt Clear_all() que ya se llama Clear()

# Parte de identificación del puerto
#port = '/dev/cu.usbmodemFA131' # nombre puerto de comunicación con el Arduino
port = 'com6'

board = pyfirmata.Arduino(port) # indica a pyfirmata el nombre del puerto serial
#sleep(5)

#Iterador recomendado para evitar la sobrecarga del puerto por los datos enviados por los pines análogos
it = pyfirmata.util.Iterator(board)
it.start()

### Programa en python que enviará y recibirá datos del Arduino
Voltaje = [] # Creación de vector de datos
Brillo = [] # Creación vector datos brillo
Data = [] # Creación matriz datos
cont = 0    # Para eliminar primer dato no numérico (None) y acotar gráficas

plt.ion() # Se le dice a pylab.py que se graficarán datos en tiempo real

a0 = board.get_pin('a:0:i') # Definición del pin de lectura
a2 = board.get_pin('a:2:i') # Definición del pin de lectura

#LED = board.get_pin('d:10:p') # Definición pin de escritura análoga
'''
a:0:i -> análogo : pin 0 : lectura (input)
d:9:i -> digital : pin 9 : lectura (input)
d:9:o -> digital : pin 9 : escritura (output)
d:9:p -> digital : pin 9 : PWM (escritura análoga)
'''
def grafica(): #crea una gráfica
    plt.plot(Voltaje, 'ro-',label='Fotoresistencia')
    plt.grid(True)
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Voltaje (V)')
    plt.ylim(0,0.5)
    plt.legend(loc='upper left')
    plt2 = plt.twinx()
    plt2.plot(Brillo,'bo-', label='Brillo')
    plt2.set_ylabel('Nivel brillo (0-255)')
    plt2.set_ylim(0,100)
    plt2.legend(loc='upper right')


try: # la parte de la rutina que se repetirá en un loop infinito
    while True: # Código dentro del loop
        
        p0 = a0.read() # Lee el pin 0
        p2 = a2.read() # Lee el pin 2
        if (type(p0)==float and type(p2)==float):
            #LED.write(brillo/255) # Envía el valor de brillo al LED (0.0,1.0)
            #print(p,',',brillo) # imprimer la variable p y brillo
            print("0: ",p0) #imprime la variable p
            print("2: ",p2) #imprime la variable p
            Voltaje.append(p0) # Adiciona el nuevo valor al arreglo
            Brillo.append(p2) # Adiciona el nuevo valor al arreglo
            drawnow(grafica) # grafica
            plt.pause(0.0001) # recomendación, razón desconocida
            sleep(0.5) # controla la velocidad de toma de datos

##            if(cont>50): # para acotar tamaño arreglos y gráficas
##                Voltaje.pop(0) # borra el primer elemento del arreglo
##                Brillo.pop(0) # borra el primer elemento del arreglo

##            if(cont>1): # condición empezar a guardar los datos a partir de dos datos

            Data = np.append(Brillo,Voltaje) # Une las dos listas en una sola
            Data = np.reshape(Data,(2,len(Voltaje))) # la organiza en foma de matriz
            Data = np.transpose(Data) # La transpone para que quede tabulada en columnas
            np.savetxt('LED-FR-rwg.txt',Data,fmt='%.4f') # Salva la tabulación

##            if(cont<3): # condición eliminar el primer valor 
##                    Voltaje.pop(0) # Elimna el primer valor del arreglo
##                    Brillo.pop(0) # Elimina primer valor del arreglo
        
except KeyboardInterrupt: # para poder salir del loop sin errores
        board.exit(0)
        os._exit(0)

